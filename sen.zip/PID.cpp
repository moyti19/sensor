#include <Arduino.h>
#include "PID.h"

static float Kp = 20.0;
static float Ki = 0.0;
static float Kd = 1.0;

static float targetAngle = 0.0;
static float integral = 0.0;
static float previousError = 0.0;
static unsigned long lastTime = 0;

float calculatePID(float currentAngle) {
  unsigned long now = micros();

  if (lastTime == 0) {
    lastTime = now;
    previousError = targetAngle - currentAngle;
    return 0;
  }

  float dt = (now - lastTime) / 1000000.0;
  lastTime = now;

  if (dt <= 0 || dt > 0.1) {
    return 0;
  }

  float error = targetAngle - currentAngle;

  integral += error * dt;
  integral = constrain(integral, -100.0f, 100.0f);

  float derivative = (error - previousError) / dt;

  float output = Kp * error
               + Ki * integral
               + Kd * derivative;

  previousError = error;

  return constrain(output, -255.0f, 255.0f);
}