#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <math.h>
#include "Sensor.h"

static Adafruit_MPU6050 mpu;
static float angle = 0.0f;
static unsigned long lastTime = 0;

bool initSensor() {
    Wire.begin(21, 22);

    if (!mpu.begin()) {
        return false;
    }

    lastTime = micros();
    return true;
}

float readAngle() {
    sensors_event_t accel, gyro, temp;
    mpu.getEvent(&accel, &gyro, &temp);

    unsigned long now = micros();
    float dt = (now - lastTime) / 1000000.0f;
    lastTime = now;

    if (dt <= 0 || dt > 0.1f) {
        return angle;
    }

    float accelAngle =
        atan2(accel.acceleration.x, accel.acceleration.z)
        * 180.0f / PI;

    float gyroRate = gyro.gyro.y * 180.0f / PI;

    angle = 0.98f * (angle + gyroRate * dt)
          + 0.02f * accelAngle;

    return angle;
}