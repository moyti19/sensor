#include <Arduino.h>
#include "Sensor.h"
#include "PID.h"

void setup() {
    Serial.begin(115200);

    if (!initSensor()) {
        Serial.println("MPU6050 not found!");

        while (true) {
            delay(10);
        }
    }

    Serial.println("Sensor and PID ready");
}

void loop() {
    float angle = readAngle();
    float output = calculatePID(angle);

    Serial.print("Angle: ");
    Serial.print(angle);
    Serial.print(" | PID output: ");
    Serial.println(output);

    delay(10);
}