#ifndef SENSOR_H
#define SENSOR_H

bool initSensor();
float readAngle();

#endif